#!/bin/bash
set -e

# Detect platform
OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
    Linux)
        PLATFORM="linux"
        WORKDIR="${WORKDIR:-/workspace/bldd}"
        TEST_BIN_DIR="${TEST_BIN_DIR:-/workspace/bin}"
        LIBC_NAME="libc"
        ;;
    Darwin)
        PLATFORM="macos"
        WORKDIR="${WORKDIR:-$(cd "$(dirname "$0")/.." && pwd)}"
        TEST_BIN_DIR="${TEST_BIN_DIR:-$WORKDIR/playground/bin}"
        LIBC_NAME="libSystem"
        ;;
    *)
        echo "Unsupported platform: $OS"
        exit 1
        ;;
esac

case "$ARCH" in
    x86_64|amd64)
        ARCH_FILTER="x86_64"
        ;;
    arm64|aarch64)
        ARCH_FILTER="aarch64"
        ;;
    *)
        ARCH_FILTER=""
        ;;
esac

cd "$WORKDIR"

echo "=== E2E Tests ==="
echo "Platform: $PLATFORM"
echo "Architecture: $ARCH"
echo "Workdir: $WORKDIR"
echo "Test binaries: $TEST_BIN_DIR"
echo ""

# Build test binaries if on macOS
if [[ "$PLATFORM" == "macos" ]]; then
    echo "=== Building test binaries ==="
    mkdir -p "$TEST_BIN_DIR"
    cd "$WORKDIR/playground/test-sources"
    make clean || true
    make all OUTPUT_DIR="$TEST_BIN_DIR"
    cd "$WORKDIR"

    echo "Built binaries:"
    ls -la "$TEST_BIN_DIR"
    echo ""
fi

# Export for tests
export TEST_BIN_DIR

# Build bldd
echo "=== Building bldd ==="
cmake -B build \
    -DCMAKE_BUILD_TYPE=Debug \
    -DBUILD_TESTING=ON \
    -DBUILD_E2E=ON

cmake --build build -j 4

# Run ctest
echo "=== Running ctest ==="
ctest --test-dir build \
    --output-on-failure \
    -j 4

# Binary integration tests
echo "=== Running binary integration tests ==="
BLDD="./build/bin/bldd"

run_test() {
    local name="$1"
    shift
    echo ""
    echo "--- Test: $name ---"
    if "$@"; then
        echo "✓ PASSED: $name"
    else
        echo "✗ FAILED: $name"
        exit 1
    fi
}

expect_output() {
    local name="$1"
    local pattern="$2"
    shift 2
    echo ""
    echo "--- Test: $name ---"
    OUTPUT=$("$@" 2>&1) || true
    echo "$OUTPUT"
    if echo "$OUTPUT" | grep -qi "$pattern"; then
        echo "✓ PASSED: $name (found: $pattern)"
    else
        echo "✗ FAILED: $name (expected: $pattern)"
        exit 1
    fi
}

# Basic tests
run_test "help" $BLDD --help
run_test "examples" $BLDD --examples
run_test "scan-directory" $BLDD -d "$TEST_BIN_DIR" -v

# Find platform libc
expect_output "find-libc" "$LIBC_NAME" $BLDD -d "$TEST_BIN_DIR" -l "$LIBC_NAME"

# Architecture filter
if [[ -n "$ARCH_FILTER" ]]; then
    run_test "arch-filter" $BLDD -d "$TEST_BIN_DIR" --arch "$ARCH_FILTER" -v
fi

# Output to file
echo ""
echo "--- Test: output-to-file ---"
$BLDD -d "$TEST_BIN_DIR" -o /tmp/bldd-report.txt
if [[ -f /tmp/bldd-report.txt ]] && [[ -s /tmp/bldd-report.txt ]]; then
    echo "✓ PASSED: output-to-file"
    cat /tmp/bldd-report.txt
else
    echo "✗ FAILED: output-to-file"
    exit 1
fi

# Non-recursive
run_test "non-recursive" $BLDD -d "$TEST_BIN_DIR" --no-recursive -v

# Multiple filters
run_test "multiple-filters" $BLDD -d "$TEST_BIN_DIR" -l "$LIBC_NAME" -l lib

# Platform-specific tests
if [[ "$PLATFORM" == "linux" ]]; then
    expect_output "find-libcrypto" "libcrypto\|crypto" $BLDD -d "$TEST_BIN_DIR" -l libcrypto
fi

if [[ "$PLATFORM" == "macos" ]]; then
    if [[ -f "$TEST_BIN_DIR/objc" ]]; then
        expect_output "find-libobjc" "libobjc\|Foundation" $BLDD -d "$TEST_BIN_DIR" -l libobjc
    fi

    if [[ -f "$TEST_BIN_DIR/openssl" ]]; then
        expect_output "find-libssl-macos" "libssl\|libcrypto\|ssl" $BLDD -d "$TEST_BIN_DIR" -l ssl
    fi
fi

# Config file test
echo ""
echo "--- Test: default-config-loading ---"
# Create default config directory and copy example config
DEFAULT_CONFIG_DIR="$HOME/.config/bldd"
DEFAULT_CONFIG_PATH="$DEFAULT_CONFIG_DIR/bldd.conf"

# Backup existing config if present
if [[ -f "$DEFAULT_CONFIG_PATH" ]]; then
    mv "$DEFAULT_CONFIG_PATH" "$DEFAULT_CONFIG_PATH.backup"
    RESTORE_CONFIG=true
else
    RESTORE_CONFIG=false
fi

# Setup test config
mkdir -p "$DEFAULT_CONFIG_DIR"
cp "$WORKDIR/config/bldd.conf.example" "$DEFAULT_CONFIG_PATH"

# Run bldd and check for config loading message
OUTPUT=$($BLDD 2>&1) || true
echo "$OUTPUT"

# Cleanup
rm -f "$DEFAULT_CONFIG_PATH"
if [[ "$RESTORE_CONFIG" == "true" ]]; then
    mv "$DEFAULT_CONFIG_PATH.backup" "$DEFAULT_CONFIG_PATH"
fi

# Check result
if echo "$OUTPUT" | grep -q "Loading configuration from default path.*bldd.conf"; then
    echo "✓ PASSED: default-config-loading"
else
    echo "✗ FAILED: default-config-loading (expected config loading message)"
    exit 1
fi

# No results case
echo ""
echo "--- Test: no-results ---"
OUTPUT=$($BLDD -d "$TEST_BIN_DIR" -l "nonexistent_lib_xyz_123" 2>&1) || true
echo "$OUTPUT"
echo "✓ PASSED: no-results"

echo ""
echo "=== All E2E tests passed! ==="
