#!/bin/bash
set -e
cd /workspace/targets

make -j$(nproc)

cd /workspace
