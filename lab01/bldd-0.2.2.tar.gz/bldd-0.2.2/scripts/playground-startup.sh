#!/bin/bash
# Runs on playground startup
set -e


if [ "${AUTO_BUILD:-true}" = "true" ]; then
    echo "AUTO_BUILD is enabled, building targets..."
    source /scripts/build-targets.sh
else
    echo "AUTO_BUILD is disabled. Set AUTO_BUILD=true to enable."
    echo "You can manually run: source /scripts/build-targets.sh"
fi

exec /bin/bash
