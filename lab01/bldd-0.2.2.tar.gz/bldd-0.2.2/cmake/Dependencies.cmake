find_package(Threads REQUIRED)


# Filesystem library (may need linking for older compilers)
include(CheckCXXSourceCompiles)
check_cxx_source_compiles("
    #include <filesystem>
    int main() {
        std::filesystem::path p;
        return 0;
    }
" HAVE_STD_FILESYSTEM)

if(NOT HAVE_STD_FILESYSTEM)
    # Try with -lstdc++fs
    set(CMAKE_REQUIRED_LIBRARIES stdc++fs)
    check_cxx_source_compiles("
        #include <filesystem>
        int main() {
            std::filesystem::path p;
            return 0;
        }
    " HAVE_STD_FILESYSTEM_WITH_LIB)
    unset(CMAKE_REQUIRED_LIBRARIES)

    if(HAVE_STD_FILESYSTEM_WITH_LIB)
        set(FILESYSTEM_LIBRARY stdc++fs)
    else()
        message(FATAL_ERROR "C++17 filesystem support required")
    endif()
endif()
