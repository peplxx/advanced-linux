#import <Foundation/Foundation.h>

int main() {
    @autoreleasepool {
        NSLog(@"Objective-C test application");
        NSString *str = @"Hello from Foundation";
        NSLog(@"%@", str);
    }
    return 0;
}
