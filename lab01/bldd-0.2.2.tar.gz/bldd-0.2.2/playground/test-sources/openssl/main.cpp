#include <iostream>
#include <openssl/evp.h>
#include <openssl/sha.h>

int main()
{
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, "test", 4);
    SHA256_Final(hash, &sha256);

    std::cout << "SHA256 hash computed\n";
    std::cout << "OpenSSL version: " << OpenSSL_version(0) << '\n';
    return 0;
}
