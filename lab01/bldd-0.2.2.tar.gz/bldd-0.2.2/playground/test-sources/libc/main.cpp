#include <stdio.h>

int main()
{
    printf("Basic Application \n");
    return 0;
}
