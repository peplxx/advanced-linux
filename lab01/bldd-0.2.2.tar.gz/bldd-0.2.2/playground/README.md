# BLDD Playground

A Docker-based environment for testing the BLDD (Backward LDD) utility with pre-built test binaries.


```bash
# Start the playground
docker-compose -f playground/docker-compose.yaml up -d

# Enter the container
docker-compose -f playground/docker-compose.yaml exec playground bash
```

## Test Binaries

Pre-built test applications are available in `/workspace/bin/`:
- **libc** - Basic application with libc dependency
- **openssl** - Application using OpenSSL libraries
- **objc** - Objective-C application (built for macOS only)

## Using BLDD

```bash
# Find executables using specific libraries
./bldd -d /workspace/bin -l libc
./bldd -d /workspace/bin -l ssl -l crypto

# Verbose output
./bldd -d /workspace/bin -v

# Filter by architecture
./bldd -d /workspace/bin --arch x86_64
```

## Included Tools

- Build tools (`gcc`, `ccache`, `clang`, `cmake`, `make`)
- Binary analysis (`file`, `ldd`, `otool`, `objdump`)
- Debugging (`strace`, `ltrace`)
- Text editors (`vim`)

## Container volume paths

```
├workspace/
├── bldd/    # BLDD source code
├── bin/     # Test binaries
├── targets/ # Test source code
└scripts/    # Utility scripts
```
