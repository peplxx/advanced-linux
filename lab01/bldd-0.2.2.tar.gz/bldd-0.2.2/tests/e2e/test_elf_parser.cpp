#include "bldd/parsers/parser_factory.h"
#include "bldd/types.h"
#include "utils.hpp"
#include <algorithm>
#include <catch2/catch_test_macros.hpp>

namespace {

using namespace bldd;

bool has_lib_containing(std::vector<std::string> const& libs, std::string const& substr)
{
    return std::any_of(libs.begin(), libs.end(),
        [&substr](std::string const& lib) {
            return lib.find(substr) != std::string::npos;
        });
}

} // namespace

TEST_CASE("[E2E] BinaryParser parse valid file", "[parser][e2e]")
{
    auto const bin_dir = get_test_bin_dir();
    auto const libc_name = get_libc_name();

    SECTION("libc binary")
    {
        auto parser = ParserFactory::create(bin_dir + "/libc");
        REQUIRE(parser != nullptr);
        REQUIRE(parser->is_valid());
        REQUIRE(parser->is_executable());
        REQUIRE(parser->get_architecture() == get_system_architecture());

        auto const libs = parser->get_libraries();
        REQUIRE(has_lib_containing(libs, libc_name));
        REQUIRE(libs.size() >= 1);
    }

    SECTION("openssl binary")
    {
        auto parser = ParserFactory::create(bin_dir + "/openssl");
        REQUIRE(parser != nullptr);
        REQUIRE(parser->is_valid());
        REQUIRE(parser->is_executable());
        REQUIRE(parser->get_architecture() == get_system_architecture());

        auto const libs = parser->get_libraries();

        REQUIRE(has_lib_containing(libs, "libcrypto"));
        REQUIRE(has_lib_containing(libs, libc_name));

        if (is_linux()) {
            REQUIRE(has_lib_containing(libs, "libstdc++"));
        }

        REQUIRE(libs.size() >= 2);
    }
}

#ifdef __APPLE__
TEST_CASE("[E2E] BinaryParser parse macOS binaries", "[parser][e2e][macos]")
{
    auto const bin_dir = get_test_bin_dir();

    SECTION("objc binary")
    {
        auto parser = ParserFactory::create(bin_dir + "/objc");
        REQUIRE(parser != nullptr);
        REQUIRE(parser->is_valid());
        REQUIRE(parser->is_executable());
        REQUIRE(parser->get_architecture() == get_system_architecture());

        auto const libs = parser->get_libraries();
        REQUIRE(has_lib_containing(libs, "libSystem"));
        REQUIRE((has_lib_containing(libs, "libobjc") || has_lib_containing(libs, "Foundation")));
    }
}
#endif
