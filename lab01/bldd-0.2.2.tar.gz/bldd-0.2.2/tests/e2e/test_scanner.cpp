#include "bldd/config.h"
#include "bldd/scanner.h"
#include "utils.hpp"
#include <catch2/catch_test_macros.hpp>
#include <set>

namespace {

using namespace bldd;

size_t count_executables(ScanResults const& results)
{
    std::set<std::string> executables;
    for (auto const& [arch, libs] : results) {
        for (auto const& [libname, binaries] : libs) {
            executables.insert(binaries.begin(), binaries.end());
        }
    }
    return executables.size();
}

} // namespace

TEST_CASE("[E2E] Scanner run scan", "[scanner][e2e]")
{
    auto const bin_dir = get_test_bin_dir();
    auto const libc_name = get_libc_name();

    // Expected: libc, openssl on both platforms; objc only on macOS
    size_t const expected_min_binaries = is_macos() ? 3 : 2;

    SECTION("Test Targets")
    {
        Config config;
        config.scan_directories = { bin_dir };

        Scanner scanner(config);
        auto const result = scanner.scan();

        REQUIRE(result.size() == 1);

        auto const& libs = result.at(get_system_architecture());
        REQUIRE(libs.size() >= 2);

        auto const exe_count = count_executables(result);
        REQUIRE(exe_count >= expected_min_binaries);
    }

    SECTION("Filter by libc")
    {
        Config config;
        config.scan_directories = { bin_dir };
        config.library_filters = { libc_name };

        Scanner scanner(config);
        auto const result = scanner.scan();

        std::set<std::string> executables;
        for (auto const& [arch, libs] : result) {
            for (auto const& [libname, binaries] : libs) {
                REQUIRE(libname.find(libc_name) != std::string::npos);
                executables.insert(binaries.begin(), binaries.end());
            }
        }
        // All binaries should link to libc/libSystem
        REQUIRE(executables.size() >= expected_min_binaries);
    }

    SECTION("Filter by libcrypto")
    {
        Config config;
        config.scan_directories = { bin_dir };
        config.library_filters = { "libcrypto" };

        Scanner scanner(config);
        auto const result = scanner.scan();

        std::set<std::string> executables;
        for (auto const& [arch, libs] : result) {
            for (auto const& [libname, binaries] : libs) {
                REQUIRE(libname.find("libcrypto") != std::string::npos);
                executables.insert(binaries.begin(), binaries.end());
            }
        }
        // Only openssl binary uses libcrypto
        REQUIRE(executables.size() == 1);
    }
}
