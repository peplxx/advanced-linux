#pragma once
#include "bldd/types.h"
#include <cstdlib>
#include <string>

namespace bldd {

inline Architecture get_system_architecture()
{
#if defined(__x86_64__) || defined(_M_X64)
    return Architecture::X86_64;
#elif defined(__i386__) || defined(_M_IX86)
    return Architecture::X86;
#elif defined(__aarch64__) || defined(_M_ARM64)
    return Architecture::AARCH64;
#elif defined(__arm__) || defined(_M_ARM)
    return Architecture::ARM;
#else
    return Architecture::UNSUPPORTED;
#endif
}

inline bool is_macos()
{
#if defined(__APPLE__)
    return true;
#else
    return false;
#endif
}

inline bool is_linux()
{
#if defined(__linux__)
    return true;
#else
    return false;
#endif
}

inline std::string get_test_bin_dir()
{
    // Allow override via environment variable
    if (auto const* env = std::getenv("TEST_BIN_DIR")) {
        return env;
    }

#if defined(__APPLE__)
    // macOS: use project-relative path
    return std::string(TEST_BIN_DIR_PATH);
#else
    // Linux: Docker volume path
    return "/workspace/bin";
#endif
}

inline std::string get_libc_name()
{
#if defined(__APPLE__)
    return "libSystem";
#else
    return "libc.so";
#endif
}

inline std::string get_libcpp_name()
{
#if defined(__APPLE__)
    return "libc++";
#else
    return "libstdc++";
#endif
}

} // namespace bldd
