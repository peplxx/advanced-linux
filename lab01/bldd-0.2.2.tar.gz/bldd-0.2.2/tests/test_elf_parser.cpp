#include "bldd/parsers/elf_parser.h"
#include <catch2/catch_test_macros.hpp>

namespace {

using namespace bldd;

}

TEST_CASE("ElfParser handles invalid files", "[elf_parser]")
{
    ElfParser parser("/nonexistent/file");
    REQUIRE_FALSE(parser.is_valid());
}

TEST_CASE("ElfParser handles non-ELF files", "[elf_parser]")
{
    ElfParser parser("/etc/passwd");
    REQUIRE_FALSE(parser.is_valid());
}
