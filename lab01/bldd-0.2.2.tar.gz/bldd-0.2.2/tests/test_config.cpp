#include "bldd/config.h"
#include <catch2/catch_test_macros.hpp>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <string>

namespace {

class TempConfigFile {
public:
    explicit TempConfigFile(std::string const& content)
        : path_(std::filesystem::temp_directory_path() / ("bldd_test_" + std::to_string(reinterpret_cast<uintptr_t>(this)) + ".conf"))
    {
        std::ofstream file(path_);
        file << content;
    }

    ~TempConfigFile()
    {
        std::filesystem::remove(path_);
    }

    TempConfigFile(TempConfigFile const&) = delete;
    TempConfigFile& operator=(TempConfigFile const&) = delete;

    std::string path() const { return path_.string(); }

private:
    std::filesystem::path path_;
};

using namespace bldd;

} // namespace

TEST_CASE("Config default values", "[config]")
{
    bldd::Config config;

    REQUIRE(config.scan_directories.size() == 0);
    REQUIRE(config.library_filters.empty());
    REQUIRE_FALSE(config.arch_filter.has_value());
    REQUIRE(config.output_format == Config::OutputFormat::TXT);
    REQUIRE(config.output_file.empty());
    REQUIRE_FALSE(config.verbose);
    REQUIRE(config.recursive);
}

TEST_CASE("Config load from nonexistent file", "[config]")
{
    auto config = bldd::Config::load_from_file("/nonexistent/path/config.conf");

    // Should return default config
    REQUIRE(config.scan_directories.size() == 0);
    REQUIRE(config.output_format == Config::OutputFormat::TXT);
}

TEST_CASE("Config load from valid file", "[config]")
{
    SECTION("Partial configuration")
    {
        TempConfigFile file(R"(
scan_directories=/custom/path
verbose=true
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 1);
        REQUIRE(config.scan_directories[0] == "/custom/path");
        REQUIRE(config.verbose);
        // Defaults preserved
        REQUIRE(config.output_format == Config::OutputFormat::TXT);
        REQUIRE(config.recursive);
    }
}

TEST_CASE("Config parsing edge cases", "[config]")
{
    SECTION("Empty file")
    {
        TempConfigFile file("");

        auto config = bldd::Config::load_from_file(file.path());

        // Should return default config
        REQUIRE(config.scan_directories.size() == 0);
    }

    SECTION("Only comments")
    {
        TempConfigFile file(R"(
# Comment 1
# Comment 2
# Comment 3
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 0);
    }

    SECTION("Whitespace handling")
    {
        TempConfigFile file(R"(
    scan_directories   =   /path/one  :  /path/two
    verbose   =   true
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 2);
        REQUIRE(config.scan_directories[0] == "/path/one");
        REQUIRE(config.scan_directories[1] == "/path/two");
        REQUIRE(config.verbose);
    }

    SECTION("Lines without equals sign are ignored")
    {
        TempConfigFile file(R"(
scan_directories=/valid/path
this line has no equals sign
verbose=true
another invalid line
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 1);
        REQUIRE(config.scan_directories[0] == "/valid/path");
        REQUIRE(config.verbose);
    }

    SECTION("Unknown keys are ignored")
    {
        TempConfigFile file(R"(
unknown_key=some_value
scan_directories=/usr/bin
another_unknown=123
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 1);
        REQUIRE(config.scan_directories[0] == "/usr/bin");
    }

    SECTION("Empty value")
    {
        TempConfigFile file(R"(
output_file=
scan_directories=/usr/bin
)");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.output_file.empty());
        REQUIRE(config.scan_directories.size() == 1);
    }

    SECTION("Single directory without colon")
    {
        TempConfigFile file("scan_directories=/single/path\n");

        auto config = bldd::Config::load_from_file(file.path());

        REQUIRE(config.scan_directories.size() == 1);
        REQUIRE(config.scan_directories[0] == "/single/path");
    }
}

TEST_CASE("Config boolean parsing", "[config]")
{
    SECTION("True values")
    {
        std::vector<std::string> true_values = { "true", "1", "yes" };

        for (auto const& val : true_values) {
            TempConfigFile file("verbose=" + val + "\n");

            auto config = bldd::Config::load_from_file(file.path());

            REQUIRE(config.verbose);
        }
    }

    SECTION("False values")
    {
        std::vector<std::string> false_values = { "false", "0", "no", "anything" };

        for (auto const& val : false_values) {
            TempConfigFile file("verbose=" + val + "\n");

            auto config = bldd::Config::load_from_file(file.path());

            REQUIRE_FALSE(config.verbose);
        }
    }
}

TEST_CASE("Config format parsing", "[config]")
{
    SECTION("txt format")
    {
        TempConfigFile file("output_format=txt\n");
        auto config = bldd::Config::load_from_file(file.path());
        REQUIRE(config.output_format == Config::OutputFormat::TXT);
    }

    SECTION("unknown format defaults to txt")
    {
        TempConfigFile file("output_format=unknown\n");
        auto config = bldd::Config::load_from_file(file.path());
        REQUIRE(config.output_format == Config::OutputFormat::TXT);
    }
}

TEST_CASE("Config example file", "[config]")
{
    TempConfigFile file(R"(
# BLDD Configuration File
# Backward LDD - Find executables using shared libraries

# Directories to scan (colon-separated)
scan_directories=/usr/bin:/usr/local/bin:/opt/bin

# Output format: txt
output_format=txt

# Default output file (empty for stdout)
output_file=

# Enable verbose output
verbose=false

# Scan directories recursively
recursive=true
)");

    auto config = bldd::Config::load_from_file(file.path());

    REQUIRE(config.scan_directories.size() == 3);
    REQUIRE(config.scan_directories[0] == "/usr/bin");
    REQUIRE(config.scan_directories[1] == "/usr/local/bin");
    REQUIRE(config.scan_directories[2] == "/opt/bin");
    REQUIRE(config.output_format == Config::OutputFormat::TXT);
    REQUIRE(config.output_file.empty());
    REQUIRE_FALSE(config.verbose);
    REQUIRE(config.recursive);
}
