#include "bldd/parsers/elf_parser.h"
#include <LIEF/ELF.hpp>

namespace bldd {

struct ElfParser::Impl {
    std::unique_ptr<LIEF::ELF::Binary> binary;
    bool loaded = false;
};

ElfParser::ElfParser(std::string const& file_path)
    : file_path_(file_path)
    , valid_(false)
    , pimpl_(std::make_unique<Impl>())
{
    try {
        pimpl_->binary = LIEF::ELF::Parser::parse(file_path);
        if (pimpl_->binary != nullptr) {
            pimpl_->loaded = true;
            valid_ = true;
        }
    } catch (std::exception const&) {
        pimpl_->loaded = false;
        valid_ = false;
    }
}

ElfParser::~ElfParser() = default;

ElfParser::ElfParser(ElfParser&&) noexcept = default;
ElfParser& ElfParser::operator=(ElfParser&&) noexcept = default;

bool ElfParser::is_valid() const
{
    return valid_ && pimpl_->loaded && pimpl_->binary;
}

bool ElfParser::is_executable() const
{
    if (!is_valid()) {
        return false;
    }

    auto type = pimpl_->binary->header().file_type();
    return type == LIEF::ELF::Header::FILE_TYPE::EXEC
        || type == LIEF::ELF::Header::FILE_TYPE::DYN;
}

BinaryFormat ElfParser::get_format() const
{
    return BinaryFormat::ELF;
}

Architecture ElfParser::get_architecture() const
{
    if (!is_valid()) {
        return Architecture::UNSUPPORTED;
    }

    auto arch = pimpl_->binary->header().machine_type();

    switch (arch) {
    case LIEF::ELF::ARCH::I386:
        return Architecture::X86;
    case LIEF::ELF::ARCH::X86_64:
        return Architecture::X86_64;
    case LIEF::ELF::ARCH::ARM:
        return Architecture::ARM;
    case LIEF::ELF::ARCH::AARCH64:
        return Architecture::AARCH64;
    default:
        return Architecture::UNSUPPORTED;
    }
}

std::vector<std::string> ElfParser::get_libraries() const
{
    std::vector<std::string> libraries;

    if (!is_valid()) {
        return libraries;
    }

    for (auto const& entry : pimpl_->binary->dynamic_entries()) {
        if (entry.tag() == LIEF::ELF::DynamicEntry::TAG::NEEDED) {
            auto const& lib = static_cast<LIEF::ELF::DynamicEntryLibrary const&>(entry);
            libraries.push_back(lib.name());
        }
    }

    return libraries;
}

std::string const& ElfParser::get_path() const
{
    return file_path_;
}

} // namespace bldd
