#include "bldd/parsers/macho_parser.h"
#include <LIEF/MachO.hpp>

namespace bldd {

struct MachoParser::Impl {
    std::unique_ptr<LIEF::MachO::FatBinary> fat_binary;
    LIEF::MachO::Binary* binary = nullptr;
    bool loaded = false;
};

MachoParser::MachoParser(std::string const& file_path)
    : file_path_(file_path)
    , valid_(false)
    , pimpl_(std::make_unique<Impl>())
{
    try {
        pimpl_->fat_binary = LIEF::MachO::Parser::parse(file_path);
        if (pimpl_->fat_binary != nullptr && pimpl_->fat_binary->size() > 0) {
            // Get the first binary (or native architecture)
            pimpl_->binary = pimpl_->fat_binary->at(0);
            pimpl_->loaded = true;
            valid_ = true;
        }
    } catch (std::exception const&) {
        pimpl_->loaded = false;
        valid_ = false;
    }
}

MachoParser::~MachoParser() = default;

MachoParser::MachoParser(MachoParser&&) noexcept = default;
MachoParser& MachoParser::operator=(MachoParser&&) noexcept = default;

bool MachoParser::is_valid() const
{
    return valid_ && pimpl_->loaded && pimpl_->binary;
}

bool MachoParser::is_executable() const
{
    if (!is_valid()) {
        return false;
    }

    auto type = pimpl_->binary->header().file_type();
    return type == LIEF::MachO::Header::FILE_TYPE::EXECUTE
        || type == LIEF::MachO::Header::FILE_TYPE::DYLIB
        || type == LIEF::MachO::Header::FILE_TYPE::BUNDLE;
}

BinaryFormat MachoParser::get_format() const
{
    return BinaryFormat::MACHO;
}

Architecture MachoParser::get_architecture() const
{
    if (!is_valid()) {
        return Architecture::UNSUPPORTED;
    }

    auto cpu_type = pimpl_->binary->header().cpu_type();

    switch (cpu_type) {
    case LIEF::MachO::Header::CPU_TYPE::X86:
        return Architecture::X86;
    case LIEF::MachO::Header::CPU_TYPE::X86_64:
        return Architecture::X86_64;
    case LIEF::MachO::Header::CPU_TYPE::ARM:
        return Architecture::ARM;
    case LIEF::MachO::Header::CPU_TYPE::ARM64:
        return Architecture::AARCH64;
    default:
        return Architecture::UNSUPPORTED;
    }
}

std::vector<std::string> MachoParser::get_libraries() const
{
    std::vector<std::string> libraries;

    if (!is_valid()) {
        return libraries;
    }

    for (auto const& cmd : pimpl_->binary->commands()) {
        if (cmd.command() == LIEF::MachO::LoadCommand::TYPE::LOAD_DYLIB
            || cmd.command() == LIEF::MachO::LoadCommand::TYPE::LOAD_WEAK_DYLIB
            || cmd.command() == LIEF::MachO::LoadCommand::TYPE::REEXPORT_DYLIB
            || cmd.command() == LIEF::MachO::LoadCommand::TYPE::LAZY_LOAD_DYLIB) {

            auto const& dylib = static_cast<LIEF::MachO::DylibCommand const&>(cmd);
            std::string name = dylib.name();

            // Extract just the library name from full path
            // e.g., "/usr/lib/libSystem.B.dylib" -> "libSystem.B.dylib"
            auto pos = name.rfind('/');
            if (pos != std::string::npos) {
                name = name.substr(pos + 1);
            }

            libraries.push_back(name);
        }
    }

    return libraries;
}

std::string const& MachoParser::get_path() const
{
    return file_path_;
}

} // namespace bldd
