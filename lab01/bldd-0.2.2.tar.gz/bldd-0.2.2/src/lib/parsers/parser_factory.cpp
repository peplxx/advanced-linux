#include "bldd/parsers/parser_factory.h"
#include "bldd/parsers/elf_parser.h"
#include "bldd/parsers/macho_parser.h"
#include <array>
#include <cstring>
#include <fstream>

namespace bldd {

namespace {

bool matches_magic(unsigned char const* data, unsigned char const* magic, size_t size)
{
    return std::memcmp(data, magic, size) == 0;
}

} // namespace

BinaryFormat ParserFactory::detect_format(std::string const& file_path)
{
    std::ifstream file(file_path, std::ios::binary);
    if (!file.is_open()) {
        return BinaryFormat::UNKNOWN;
    }

    std::array<unsigned char, 8> magic {};
    file.read(reinterpret_cast<char*>(magic.data()), magic.size());

    if (file.gcount() < 4) {
        return BinaryFormat::UNKNOWN;
    }

    // Check ELF magic
    if (matches_magic(magic.data(), kElfMagic, 4)) {
        return BinaryFormat::ELF;
    }

    // Check Mach-O magic (various formats)
    if (matches_magic(magic.data(), kMachoMagic32, 4)
        || matches_magic(magic.data(), kMachoMagic64, 4)
        || matches_magic(magic.data(), kMachoMagic32Rev, 4)
        || matches_magic(magic.data(), kMachoMagic64Rev, 4)
        || matches_magic(magic.data(), kMachoFatMagic, 4)
        || matches_magic(magic.data(), kMachoFatMagicRev, 4)) {
        return BinaryFormat::MACHO;
    }

    return BinaryFormat::UNKNOWN;
}

BinaryParserPtr ParserFactory::create(std::string const& file_path)
{
    auto format = detect_format(file_path);
    return create(file_path, format);
}

BinaryParserPtr ParserFactory::create(std::string const& file_path, BinaryFormat format)
{
    switch (format) {
    case BinaryFormat::ELF:
        return std::make_unique<ElfParser>(file_path);
    case BinaryFormat::MACHO:
        return std::make_unique<MachoParser>(file_path);
    case BinaryFormat::UNKNOWN:
        return nullptr;
    }
    return nullptr;
}

} // namespace bldd
