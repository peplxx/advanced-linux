#include "bldd/report.h"
#include <algorithm>
#include <cassert>
#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>
#include <string>

namespace bldd {

ReportGenerator::ReportGenerator(Config const& config)
    : config_(config)
{
}

std::vector<ReportEntry> ReportGenerator::generate(ScanResults const& results)
{
    std::vector<ReportEntry> entries;

    for (auto const& [arch, libs] : results) {
        for (auto const& [lib_name, executables] : libs) {
            ReportEntry entry;
            entry.library_name = lib_name;
            entry.architecture = arch;
            entry.executables = executables;
            entries.push_back(entry);
        }
    }

    std::sort(entries.begin(), entries.end());

    return entries;
}

void ReportGenerator::write(std::ostream& os, std::vector<ReportEntry> const& entries) const
{
    switch (config_.output_format) {
    case Config::OutputFormat::TXT:
        write_txt(os, entries);
        return;
    }
    assert(false && "Unreachable: unhandled output format");
}

bool ReportGenerator::write_to_file(std::string const& filename,
    std::vector<ReportEntry> const& entries) const
{
    std::ofstream file(filename);
    if (!file.is_open()) {
        return false;
    }
    write(file, entries);
    return true;
}

void ReportGenerator::write_txt(std::ostream& os, std::vector<ReportEntry> const& entries)
{
    if (entries.empty()) {
        os << "No libraries found matching the criteria.\n";
        return;
    }
    std::set<std::string> execs;
    for (auto const& entry : entries) {
        os << entry.library_name << " [" << to_string(entry.architecture) << ']';
        os << " (" << entry.usage_count() << " execs):\n";
        std::for_each(entry.executables.begin(), entry.executables.end(), [&](std::string const& exe) {
            execs.insert(exe);
            os << "    " << entry.library_name << " -> " << exe << "\n";
        });
        os << "\n";
    }

    os << "----------------------------------------\n";
    os << "libs total: " << entries.size() << "\n";
    os << "execs total: " << execs.size() << "\n";
}

} // namespace bldd
