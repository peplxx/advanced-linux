#include "bldd/config.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace {

void trim(std::string& str)
{
    auto const* const whitespace = " \t";
    str.erase(0, str.find_first_not_of(whitespace));
    auto const last = str.find_last_not_of(whitespace);
    if (last != std::string::npos) {
        str.erase(last + 1);
    }
}

bool parse_bool(std::string const& value)
{
    return value == "true" || value == "1" || value == "yes";
}

std::vector<std::string> parse_path_list(std::string const& value, char delimiter = ':')
{
    std::vector<std::string> paths;
    std::stringstream ss(value);
    std::string path;

    while (std::getline(ss, path, delimiter)) {
        trim(path);
        if (!path.empty()) {
            paths.push_back(path);
        }
    }

    return paths;
}

bool is_comment_or_empty(std::string const& line)
{
    return line.empty() || line[0] == '#';
}

std::pair<std::string, std::string> parse_key_value(std::string const& line)
{
    auto const pos = line.find('=');
    if (pos == std::string::npos) {
        return { "", "" };
    }

    std::string key = line.substr(0, pos);
    std::string value = line.substr(pos + 1);

    trim(key);
    trim(value);

    return { key, value };
}

} // namespace

namespace bldd {

Config Config::load_from_file(std::string const& config_path)
{
    Config config;

    std::ifstream file(config_path);
    if (!file.is_open()) {
        std::cerr << "Config: Failed to open file: " << config_path << "\n";
        return config;
    }

    std::string line;
    while (std::getline(file, line)) {
        if (is_comment_or_empty(line)) {
            continue;
        }

        auto const [key, value] = parse_key_value(line);
        if (key.empty()) {
            continue;
        }

        if (key == "scan_directories") {
            config.scan_directories = parse_path_list(value);
        } else if (key == "output_format") {
            config.output_format = format_from_string(value);
        } else if (key == "output_file") {
            config.output_file = value;
        } else if (key == "verbose") {
            config.verbose = parse_bool(value);
        } else if (key == "recursive") {
            config.recursive = parse_bool(value);
        } else if (key == "symlinks") {
            config.symlinks = parse_bool(value);
        }
    }

    if (file.bad()) {
        std::cerr << "Config: Error reading file: " << config_path << "\n";
    }

    return config;
}

} // namespace bldd
