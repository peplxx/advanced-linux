#include "bldd/scanner.h"
#include "bldd/parsers/parser_factory.h"
#include <algorithm>
#include <filesystem>
#include <iostream>
#include <unordered_set>
namespace {

namespace fs = std::filesystem;

}

namespace bldd {

Scanner::Scanner(Config const& config)
    : config_(config)
    , stats_()
{
}

void Scanner::default_callback(std::string const& filename, size_t index, size_t total)
{
    std::cerr << "\r[" << index << "/" << total << "] Scanning: " << filename << std::flush;
    if (index == total) {
        std::cerr << '\n';
    }
}

bool Scanner::matches_library_filter(std::string const& lib_name) const
{
    if (config_.library_filters.empty()) {
        return true;
    }

    for (auto const& filter : config_.library_filters) {
        if (lib_name.find(filter) != std::string::npos) {
            return true;
        }
    }
    return false;
}

ScanResults Scanner::scan(ProgressCallback const& callback)
{
    ScanResults results;
    stats_ = Stats();

    std::vector<std::string> all_files;
    std::unordered_set<std::string> processed_paths;

    for (auto const& dir : config_.scan_directories) {
        if (!fs::exists(dir)) {
            if (config_.verbose) {
                std::cerr << "Warning: Directory does not exist: " << dir << "\n";
            }
            continue;
        }

        fs::path abs_dir = fs::canonical(fs::absolute(dir));
        if (config_.verbose) {
            std::cerr << "Scanning directory: " << abs_dir.string() << '\n';
        }

        auto files = find_all_files(abs_dir.string(), processed_paths);
        all_files.insert(all_files.end(), files.begin(), files.end());
    }

    size_t total_files = all_files.size();

    for (size_t i = 0; i < all_files.size(); ++i) {
        auto const& file = all_files[i];
        stats_.files_scanned++;

        if (callback && config_.verbose) {
            callback(file, i + 1, total_files);
        }

        try {
            auto parser = ParserFactory::create(file);

            if (!parser || !parser->is_valid()) {
                if (config_.verbose) {
                    std::cerr << file << " not valid or unsupported format\n";
                }
                continue;
            }

            if (!parser->is_executable()) {
                continue;
            }

            Architecture arch = parser->get_architecture();
            if (arch == Architecture::UNSUPPORTED) {
                continue;
            }

            if (config_.arch_filter.has_value() && arch != config_.arch_filter.value()) {
                continue;
            }

            if (config_.format_filter.has_value() && parser->get_format() != config_.format_filter.value()) {
                continue;
            }

            stats_.executables_found++;

            if (config_.verbose) {
                std::cerr << "  Found " << to_string(parser->get_format())
                          << " executable: " << file << "\n";
            }

            for (auto const& lib : parser->get_libraries()) {
                if (matches_library_filter(lib)) {
                    results[arch][lib].push_back(file);
                }
            }

        } catch (std::exception const& e) {
            if (config_.verbose) {
                std::cerr << "Error parsing " << file << ": " << e.what() << '\n';
            }
            continue;
        }
    }

    for (auto const& [arch, libs] : results) {
        stats_.libraries_found += libs.size();
    }

    return results;
}

std::vector<std::string> Scanner::find_all_files(std::string const& directory,
    std::unordered_set<std::string>& processed_paths) const
{
    std::vector<std::string> files;

    try {
        if (config_.recursive) {
            for (auto const& entry : fs::recursive_directory_iterator(
                     directory, fs::directory_options::skip_permission_denied | fs::directory_options::follow_directory_symlink)) {

                process_entry(entry, files, processed_paths);
            }
        } else {
            for (auto const& entry : fs::directory_iterator(
                     directory, fs::directory_options::skip_permission_denied)) {

                process_entry(entry, files, processed_paths);
            }
        }
    } catch (fs::filesystem_error const& e) {
        if (config_.verbose) {
            std::cerr << "Error accessing directory: " << e.what() << '\n';
        }
    }

    return files;
}

void Scanner::process_entry(fs::directory_entry const& entry,
    std::vector<std::string>& files,
    std::unordered_set<std::string>& processed_paths) const
{
    try {
        fs::path const& entry_path = entry.path();
        // Symlink
        if (entry.is_symlink() && config_.symlinks) {
            if (config_.verbose) {
                std::cerr << "Found symlink: " << entry_path.string() << " -> ";
            }
            try {
                fs::path target = fs::read_symlink(entry_path);

                // If target is relative, make it absolute relative to the symlink's directory
                if (target.is_relative()) {
                    target = entry_path.parent_path() / target;
                }

                // Canonicalize to get the absolute path
                if (fs::exists(target)) {
                    target = fs::canonical(target);

                    if (config_.verbose) {
                        std::cerr << target.string() << '\n';
                    }

                    // Check if we've already processed this target
                    if (processed_paths.find(target.string()) != processed_paths.end()) {
                        if (config_.verbose) {
                            std::cerr << "  Already processed: " << target.string() << '\n';
                        }
                        return;
                    }

                    // If the target is a regular file, add it
                    if (fs::is_regular_file(target)) {
                        files.push_back(target.string());
                        processed_paths.insert(target.string());

                        if (config_.verbose) {
                            std::cerr << "  Added symlink target: " << target.string() << '\n';
                        }
                    }
                } else {
                    if (config_.verbose) {
                        std::cerr << "broken link\n";
                    }
                }
            } catch (fs::filesystem_error const& e) {
                if (config_.verbose) {
                    std::cerr << "Error resolving symlink: " << e.what() << '\n';
                }
            }
        }
        // Regular file
        else if (entry.is_regular_file() && !entry.is_symlink()) {
            try {
                fs::path canonical_path = fs::canonical(entry_path);

                // Check if we've already processed this file
                if (processed_paths.find(canonical_path.string()) == processed_paths.end()) {
                    files.push_back(canonical_path.string());
                    processed_paths.insert(canonical_path.string());
                }
            } catch (fs::filesystem_error const& e) {
                if (config_.verbose) {
                    std::cerr << "Error canonicalizing path: " << e.what() << '\n';
                }
                // Fallback: add the original path if we can't canonicalize
                files.push_back(entry_path.string());
            }
        }
    } catch (fs::filesystem_error const& e) {
        if (config_.verbose) {
            std::cerr << "Error processing entry: " << e.what() << '\n';
        }
    }
}

} // namespace bldd
