#include "cmd/cli.h"
#include "cmd/runner.h"

int main(int argc, char* argv[])
{
    bldd::cmd::Cli cli;
    auto result = cli.parse(argc, argv);

    if (result.should_exit) {
        return result.exit_code;
    }

    return bldd::cmd::run(result.config);
}
