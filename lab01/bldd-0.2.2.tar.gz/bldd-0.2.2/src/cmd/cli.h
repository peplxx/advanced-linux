#pragma once

#include "bldd/config.h"
#include <argparse/argparse.hpp>
#include <optional>
#include <string>
#include <vector>

namespace bldd::cmd {

struct CliResult {
    bool should_exit = false;
    int exit_code = 0;
    Config config;
};

class Cli {
public:
    Cli();

    CliResult parse(int argc, char* argv[]);

private:
    static void print_examples();
    void setup_arguments();
    Config build_config() const;

    argparse::ArgumentParser program_;
};

} // namespace bldd::cmd
