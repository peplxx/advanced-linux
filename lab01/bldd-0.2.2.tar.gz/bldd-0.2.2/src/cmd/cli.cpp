#include "cli.h"
#include "bldd/config.h"
#include <filesystem>
#include <iostream>

namespace bldd::cmd {

namespace {

constexpr auto kVersion = "0.2.2";

constexpr auto kDescription = "Backward LDD - Find all executable files that use specified shared libraries.\n"
                              "This tool scans directories for ELF executables and reports which executables\n"
                              "depend on which shared libraries, organized by architecture.";

constexpr auto kEpilog = "Use --examples for detailed usage examples.\n"
                         "Report bugs to: https://github.com/peplxx/bldd/issues";

constexpr auto kExamples = R"(
EXAMPLES:
  # Find all executables using libc in /usr/bin
  bldd -d /usr/bin -l libc

  # Find executables using libssl or libcrypto, output to file
  bldd -d /usr/bin -l libssl -l libcrypto -o report.txt

  # Scan multiple directories for x86_64 binaries only
  bldd -d /usr/bin -d /usr/local/bin --arch x86_64

  # Scan with verbose output
  bldd -d /usr/bin -v

  # Scan without recursion
  bldd -d /opt --no-recursive

  # Scan without symlinks
  bldd -d /usr/bin --no-symlinks

ARCHITECTURES:
  Supported: x86 (i386), x86_64 (amd64), armv7, aarch64 (arm64)

REPORT FORMAT:
  Results are sorted by usage count (high -> low)
)";

} // namespace

Cli::Cli()
    : program_("bldd", kVersion)
{
    program_.add_description(kDescription);
    program_.add_epilog(kEpilog);
    setup_arguments();
}

void Cli::setup_arguments()
{
    program_.add_argument("-d", "--directory")
        .help("Directory to scan for executables (can be specified multiple times)")
        .append()
        .default_value(std::vector<std::string> {});

    program_.add_argument("-l", "--library")
        .help("Library name to search for (can be specified multiple times, partial match)")
        .append()
        .default_value(std::vector<std::string> {});

    program_.add_argument("-a", "--arch")
        .help("Filter by architecture: x86, x86_64, armv7, aarch64")
        .default_value(std::string {});

    program_.add_argument("-o", "--output")
        .help("Output file for the report (default: stdout)")
        .default_value(std::string {});

    program_.add_argument("-f", "--format")
        .help("Output format: txt")
        .default_value(std::string { "txt" });

    program_.add_argument("--bformat")
        .help("Filter by binary format: elf, macho, all")
        .default_value(std::string { "all" });

    program_.add_argument("-c", "--config")
        .help("Path to configuration file")
        .default_value(std::string {});

    program_.add_argument("-v", "--verbose")
        .help("Enable verbose output")
        .default_value(false)
        .implicit_value(true);

    program_.add_argument("--no-symlinks")
        .help("Do not scan symlinks in directories")
        .default_value(false)
        .implicit_value(true);

    program_.add_argument("--no-recursive")
        .help("Do not scan directories recursively")
        .default_value(false)
        .implicit_value(true);

    program_.add_argument("--examples")
        .help("Show usage examples")
        .default_value(false)
        .implicit_value(true);
}

void Cli::print_examples()
{
    std::cout << kExamples;
}

Config Cli::build_config() const
{
    Config config;

    auto default_path = Config::get_default_path();
    if (!default_path.empty() && std::filesystem::exists(default_path)) {
        std::cerr << "Loading configuration from default path: "
                  << default_path << "\n";
        config = Config::load_from_file(default_path.string());
    }

    // Load from config file if specified
    auto config_path = program_.get<std::string>("--config");
    if (!config_path.empty()) {
        std::cerr << "Loading configuration from: " << config_path << "\n";
        config = Config::load_from_file(config_path);
    }

    // Override with command line arguments
    auto directories = program_.get<std::vector<std::string>>("--directory");
    if (!directories.empty()) {
        config.scan_directories = directories;
    }

    config.library_filters = program_.get<std::vector<std::string>>("--library");
    config.output_file = program_.get<std::string>("--output");
    config.output_format = format_from_string(program_.get<std::string>("--format"));

    // Parse explicit flags
    if (program_.get<bool>("--verbose"))
        config.verbose = program_.get<bool>("--verbose");

    if (program_.get<bool>("--no-recursive"))
        config.recursive = !program_.get<bool>("--no-recursive");

    if (program_.get<bool>("--no-symlinks"))
        config.symlinks = !program_.get<bool>("--no-symlinks");

    // Parse architecture filter
    auto arch_str = program_.get<std::string>("--arch");
    if (!arch_str.empty()) {
        config.arch_filter = arch_from_string(arch_str);
    }
    auto format_str = program_.get<std::string>("--format");
    if (format_str == "elf") {
        config.format_filter = BinaryFormat::ELF;
    } else if (format_str == "macho") {
        config.format_filter = BinaryFormat::MACHO;
    }

    return config;
}

CliResult Cli::parse(int argc, char* argv[])
{
    CliResult result;

    try {
        program_.parse_args(argc, argv);
    } catch (std::exception const& err) {
        std::cerr << err.what() << '\n';
        std::cerr << program_;
        result.should_exit = true;
        result.exit_code = 1;
        return result;
    }

    if (program_.get<bool>("--examples")) {
        print_examples();
        result.should_exit = true;
        result.exit_code = 0;
        return result;
    }

    result.config = build_config();

    // Validate architecture
    auto arch_str = program_.get<std::string>("--arch");
    if (!arch_str.empty() && result.config.arch_filter == Architecture::UNSUPPORTED) {
        std::cerr << "Error: Unsupported architecture '" << arch_str << "'\n";
        std::cerr << "Supported: x86, x86_64, armv7, aarch64\n";
        result.should_exit = true;
        result.exit_code = 1;
        return result;
    }

    return result;
}

} // namespace bldd::cmd
