#include "bldd/report.h"
#include "bldd/scanner.h"
#include "cli.h"
#include <iostream>

namespace bldd::cmd {

namespace {

void print_config(Config const& config)
{
    std::cerr << "Configuration:\n";
    std::cerr << "  Directories: ";
    for (auto const& d : config.scan_directories) {
        std::cerr << d << " ";
    }
    std::cerr << "\n";

    if (!config.library_filters.empty()) {
        std::cerr << "  Library filters: ";
        for (auto const& l : config.library_filters) {
            std::cerr << l << " ";
        }
        std::cerr << "\n";
    }

    if (config.arch_filter.has_value()) {
        std::cerr << "  Architecture filter: " << to_string(config.arch_filter.value()) << "\n";
    }

    std::cerr << "\n";
}

void print_stats(Scanner::Stats const& stats)
{
    std::cerr << "\nScan complete:\n";
    std::cerr << "  Files scanned:     " << stats.files_scanned << "\n";
    std::cerr << "  Executables found: " << stats.executables_found << "\n";
    std::cerr << "  Libraries found:   " << stats.libraries_found << "\n\n";
}

bool write_report(Config const& config, std::vector<ReportEntry> const& entries)
{
    ReportGenerator generator(config);

    if (config.output_file.empty()) {
        generator.write(std::cout, entries);
        return true;
    }

    if (generator.write_to_file(config.output_file, entries)) {
        std::cerr << "Report written to: " << config.output_file << "\n";
        return true;
    }

    std::cerr << "Error: Could not write to file: " << config.output_file << "\n";
    return false;
}

} // namespace

int run(Config const& config)
{
    if (config.verbose) {
        print_config(config);
    }

    Scanner scanner(config);
    auto results = scanner.scan({});

    if (config.verbose) {
        print_stats(scanner.get_stats());
    }

    auto entries = ReportGenerator::generate(results);

    return write_report(config, entries) ? 0 : 1;
}

} // namespace bldd::cmd
