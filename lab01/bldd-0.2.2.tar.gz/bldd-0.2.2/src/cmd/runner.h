#pragma once

#include "bldd/config.h"

namespace bldd::cmd {

int run(Config const& config);

} // namespace bldd::cmd
