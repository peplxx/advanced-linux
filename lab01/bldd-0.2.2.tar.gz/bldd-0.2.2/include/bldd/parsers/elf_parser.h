#pragma once

#include "bldd/parsers/binary_parser.h"
#include "bldd/types.h"
#include <memory>
#include <string>
#include <vector>

namespace bldd {

class ElfParser : public BinaryParser {
public:
    explicit ElfParser(std::string const& file_path);
    ~ElfParser() override;

    // Non-copyable, movable
    ElfParser(ElfParser const&) = delete;
    ElfParser& operator=(ElfParser const&) = delete;
    ElfParser(ElfParser&&) noexcept;
    ElfParser& operator=(ElfParser&&) noexcept;

    [[nodiscard]] bool is_valid() const override;
    [[nodiscard]] bool is_executable() const override;
    [[nodiscard]] BinaryFormat get_format() const override;
    [[nodiscard]] Architecture get_architecture() const override;
    [[nodiscard]] std::vector<std::string> get_libraries() const override;
    [[nodiscard]] std::string const& get_path() const override;

private:
    struct Impl;
    std::string file_path_;
    bool valid_;
    std::unique_ptr<Impl> pimpl_;
};

} // namespace bldd
