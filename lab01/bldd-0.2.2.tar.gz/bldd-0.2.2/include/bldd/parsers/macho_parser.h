#pragma once

#include "bldd/parsers/binary_parser.h"
#include "bldd/types.h"
#include <memory>
#include <string>
#include <vector>

namespace bldd {

class MachoParser : public BinaryParser {
public:
    explicit MachoParser(std::string const& file_path);
    ~MachoParser() override;

    // Non-copyable, movable
    MachoParser(MachoParser const&) = delete;
    MachoParser& operator=(MachoParser const&) = delete;
    MachoParser(MachoParser&&) noexcept;
    MachoParser& operator=(MachoParser&&) noexcept;

    [[nodiscard]] bool is_valid() const override;
    [[nodiscard]] bool is_executable() const override;
    [[nodiscard]] BinaryFormat get_format() const override;
    [[nodiscard]] Architecture get_architecture() const override;
    [[nodiscard]] std::vector<std::string> get_libraries() const override;
    [[nodiscard]] std::string const& get_path() const override;

private:
    struct Impl;
    std::string file_path_;
    bool valid_;
    std::unique_ptr<Impl> pimpl_;
};

} // namespace bldd
