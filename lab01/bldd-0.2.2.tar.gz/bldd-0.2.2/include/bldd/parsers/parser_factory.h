#pragma once

#include "bldd/parsers/binary_parser.h"
#include <string>

namespace bldd {

class ParserFactory {
public:
    /// Detect binary format from file magic bytes
    [[nodiscard]] static BinaryFormat detect_format(std::string const& file_path);

    /// Create appropriate parser based on detected format
    [[nodiscard]] static BinaryParserPtr create(std::string const& file_path);

    /// Create parser for specific format
    [[nodiscard]] static BinaryParserPtr create(std::string const& file_path, BinaryFormat format);

private:
    static constexpr unsigned char kElfMagic[] = { 0x7f, 'E', 'L', 'F' };
    static constexpr unsigned char kMachoMagic32[] = { 0xfe, 0xed, 0xfa, 0xce };
    static constexpr unsigned char kMachoMagic64[] = { 0xfe, 0xed, 0xfa, 0xcf };
    static constexpr unsigned char kMachoMagic32Rev[] = { 0xce, 0xfa, 0xed, 0xfe };
    static constexpr unsigned char kMachoMagic64Rev[] = { 0xcf, 0xfa, 0xed, 0xfe };
    static constexpr unsigned char kMachoFatMagic[] = { 0xca, 0xfe, 0xba, 0xbe };
    static constexpr unsigned char kMachoFatMagicRev[] = { 0xbe, 0xba, 0xfe, 0xca };
};

} // namespace bldd
