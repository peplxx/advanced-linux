#pragma once

#include "bldd/types.h"
#include <memory>
#include <string>
#include <vector>

namespace bldd {

class BinaryParser {
public:
    virtual ~BinaryParser() = default;

    /// Check if the binary was parsed successfully
    [[nodiscard]] virtual bool is_valid() const = 0;

    /// Check if this is an executable (not just a library)
    [[nodiscard]] virtual bool is_executable() const = 0;

    /// Get the binary format (ELF, Mach-O, etc.)
    [[nodiscard]] virtual BinaryFormat get_format() const = 0;

    /// Get the architecture of the binary
    [[nodiscard]] virtual Architecture get_architecture() const = 0;

    /// Get list of shared libraries this binary depends on
    [[nodiscard]] virtual std::vector<std::string> get_libraries() const = 0;

    /// Get the file path
    [[nodiscard]] virtual std::string const& get_path() const = 0;

protected:
    BinaryParser() = default;
    BinaryParser(BinaryParser const&) = default;
    BinaryParser(BinaryParser&&) = default;
    BinaryParser& operator=(BinaryParser const&) = default;
    BinaryParser& operator=(BinaryParser&&) = default;
};

using BinaryParserPtr = std::unique_ptr<BinaryParser>;

} // namespace bldd
