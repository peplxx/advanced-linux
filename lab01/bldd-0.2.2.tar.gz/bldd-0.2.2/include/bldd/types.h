#pragma once

#include <map>
#include <optional>
#include <string>
#include <vector>

namespace bldd {

enum class Architecture {
    X86,
    X86_64,
    ARM,
    AARCH64,
    UNSUPPORTED
};

enum class BinaryFormat {
    ELF,
    MACHO,
    UNKNOWN
};

inline std::string to_string(Architecture arch)
{
    switch (arch) {
    case Architecture::X86:
        return "x86";
    case Architecture::X86_64:
        return "x86_64";
    case Architecture::ARM:
        return "armv7";
    case Architecture::AARCH64:
        return "aarch64";
    case Architecture::UNSUPPORTED:
        return "unsupported";
    }
    return "unknown";
}

inline std::string to_string(BinaryFormat format)
{
    switch (format) {
    case BinaryFormat::ELF:
        return "ELF";
    case BinaryFormat::MACHO:
        return "Mach-O";
    case BinaryFormat::UNKNOWN:
        return "Unknown";
    }
    return "unknown";
}

inline Architecture arch_from_string(std::string const& str)
{
    if (str == "x86" || str == "i386" || str == "i686") {
        return Architecture::X86;
    }
    if (str == "x86_64" || str == "amd64") {
        return Architecture::X86_64;
    }
    if (str == "arm" || str == "armv7" || str == "armhf") {
        return Architecture::ARM;
    }
    if (str == "aarch64" || str == "arm64") {
        return Architecture::AARCH64;
    }
    return Architecture::UNSUPPORTED;
}

// Library -> list of executables using it
using LibraryUsageMap = std::map<std::string, std::vector<std::string>>;

// Architecture -> library usage
using ScanResults = std::map<Architecture, LibraryUsageMap>;

} // namespace bldd
