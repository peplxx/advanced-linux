#pragma once

#include "config.h"
#include "types.h"
#include <ostream>
#include <string>
#include <vector>

namespace bldd {

struct ReportEntry {
    std::string library_name;
    Architecture architecture;
    std::vector<std::string> executables;

    size_t usage_count() const { return executables.size(); }

    bool operator<(ReportEntry const& other) const
    {
        return usage_count() > other.usage_count();
    }
};

class ReportGenerator {
public:
    explicit ReportGenerator(Config const& config);

    static std::vector<ReportEntry> generate(ScanResults const& results);

    void write(std::ostream& os, std::vector<ReportEntry> const& entries) const;

    bool write_to_file(std::string const& filename, std::vector<ReportEntry> const& entries) const;

private:
    static void write_txt(std::ostream& os, std::vector<ReportEntry> const& entries);

    Config config_;
};

} // namespace bldd
