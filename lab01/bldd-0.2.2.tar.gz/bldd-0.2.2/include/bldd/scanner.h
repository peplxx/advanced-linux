#pragma once

#include "config.h"
#include "types.h"
#include <functional>
#include <string>
#include <unordered_set>
#include <vector>

namespace bldd {

class Scanner {
public:
    struct Stats {
        size_t files_scanned = 0;
        size_t executables_found = 0;
        size_t libraries_found = 0;
    };

    using ProgressCallback = std::function<void(std::string const&, size_t, size_t)>;

    explicit Scanner(Config const& config);

    ScanResults scan(ProgressCallback const& callback = nullptr);

    Stats const& get_stats() const { return stats_; }

private:
    static void default_callback(std::string const& filename, size_t index, size_t total);

    void process_entry(std::filesystem::directory_entry const& entry,
        std::vector<std::string>& files,
        std::unordered_set<std::string>& processed_paths) const;

    std::vector<std::string> find_all_files(std::string const& directory,
        std::unordered_set<std::string>& processed_paths) const;

    bool matches_library_filter(std::string const& lib_name) const;

    Config config_;
    Stats stats_;
};

} // namespace bldd
