#pragma once

#include "bldd/types.h"
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace bldd {

struct Config {
    enum class OutputFormat : uint8_t {
        TXT,
    };

    std::vector<std::string> scan_directories;
    OutputFormat output_format;
    std::string output_file;

    // Filters
    std::vector<std::string> library_filters;  // Libraries to search for (nullopt = all)
    std::optional<Architecture> arch_filter;   // Filter by architecture  (nullopt = all)
    std::optional<BinaryFormat> format_filter; // Filter by binary format (nullopt = all)

    bool verbose = false;
    bool symlinks = true;
    bool recursive = true;

    Config()
        : scan_directories({})
        , output_format(OutputFormat::TXT)
    {
    }

    static Config load_from_file(std::string const& config_path);
    static constexpr std::string_view kDefaultConfigPath = ".config/bldd/bldd.conf";
    static std::filesystem::path get_default_path()
    {
        char const* home = getenv("HOME");
        return home ? std::filesystem::path(home) / kDefaultConfigPath : std::filesystem::path {};
    }
};

inline Config::OutputFormat format_from_string(std::string const&)
{
    return Config::OutputFormat::TXT;
}

} // namespace bldd
